import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Cide365 | Köyden sofrana",
  description: "Cide'nin ve Türkiye'nin üreticilerini tüketicilerle buluşturan yerel ürün pazaryeri."
};

export default function RootLayout({
  children
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="tr">
      <body>{children}</body>
    </html>
  );
}
