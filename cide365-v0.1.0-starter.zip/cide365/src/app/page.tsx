const categories = [
  { name: "Fındık", detail: "Cide ve çevresinden fındık ürünleri", icon: "🌰" },
  { name: "Bal", detail: "Üreticisinden bal ve arı ürünleri", icon: "🍯" },
  { name: "Kestane", detail: "Kestane ve yöresel tatlar", icon: "🌰" },
  { name: "Kurutulmuş meyve", detail: "Doğal meyve atıştırmalıkları", icon: "🍎" },
  { name: "Köy ürünleri", detail: "Mevsimlik sebze ve meyveler", icon: "🥬" },
  { name: "Deniz ürünleri", detail: "Uygun koşullarda gönderilebilen ürünler", icon: "🐟" }
];

export default function Home() {
  return (
    <main>
      <header className="topbar">
        <a className="brand" href="/">Cide<span>365</span></a>
        <nav aria-label="Ana menü">
          <a href="#kategoriler">Kategoriler</a>
          <a href="#ureticiler">Üreticiler</a>
          <a href="#nasil-calisir">Nasıl çalışır?</a>
        </nav>
        <a className="login" href="#uye-ol">Giriş / Üye ol</a>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">CİDE'DEN TÜRKİYE'YE</p>
          <h1>Köyden sofrana,<br /><em>Türkiye'nin üreticisi.</em></h1>
          <p className="intro">
            Yerel üreticilerin emeğini, güvenilir alışverişle Türkiye'nin
            dört bir yanına ulaştırıyoruz.
          </p>
          <div className="hero-actions">
            <a className="primary" href="#kategoriler">Ürünleri keşfet</a>
            <a className="secondary" href="#ureticiler">Üretici ol</a>
          </div>
        </div>
        <div className="hero-art" role="img" aria-label="Yöresel ürünleri temsil eden illüstrasyon">
          <div className="sun"></div>
          <div className="basket">🌰 🍯 🍎</div>
          <p>Cide'nin bereketi</p>
        </div>
      </section>

      <section className="trust-strip" id="nasil-calisir">
        <div><strong>Ücretsiz</strong><span>Üretici üyeliği</span></div>
        <div><strong>%5</strong><span>Satış başına platform komisyonu</span></div>
        <div><strong>Türkiye</strong><span>Geneline ulaşma hedefi</span></div>
      </section>

      <section className="section" id="kategoriler">
        <div className="section-heading">
          <div><p className="eyebrow">YÖRESEL ÜRÜNLER</p><h2>Ürün kategorileri</h2></div>
          <span className="muted">İlk aşama: Cide</span>
        </div>
        <div className="category-grid">
          {categories.map((category) => (
            <article className="category-card" key={category.name}>
              <div className="category-icon" aria-hidden="true">{category.icon}</div>
              <h3>{category.name}</h3>
              <p>{category.detail}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="producer-callout" id="ureticiler">
        <div>
          <p className="eyebrow">ÜRETİCİLERE ÇAĞRI</p>
          <h2>Üretmek sizden,<br />Türkiye'ye ulaştırmak Cide365'ten.</h2>
          <p>Mağazanızı ücretsiz açın. Satış yaptığınızda %5 komisyon ödeyin.</p>
        </div>
        <a className="primary light" id="uye-ol" href="mailto:bilgi@cide365.com?subject=Üretici%20başvurusu">
          Üretici başvurusu
        </a>
      </section>

      <footer>
        <a className="brand" href="/">Cide<span>365</span></a>
        <p>Üreticiyi büyüt. Yereli yaşat. Türkiye'ye ulaştır.</p>
        <small>© {new Date().getFullYear()} Cide365. Taslak geliştirme sürümü.</small>
      </footer>
    </main>
  );
}
